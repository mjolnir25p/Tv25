# Compilar StreamAI

GitHub Actions compila a pasta StreamAI com JDK 17, Gradle 8.11.1, AGP 8.9.2 e Android SDK 35. O workflow usa Gradle instalado por setup-gradle; este projeto não inclui o executável/JAR do Wrapper.

Em Actions, abre Build StreamAI APK e descarrega StreamAI-debug-APK após sucesso. Extrai o ZIP e instala app-debug.apk. É um APK de teste, não uma versão de produção.

Localmente: abre StreamAI no Android Studio ou instala Gradle 8.11.1 e executa `gradle :app:assembleDebug`.

As funções AI precisam de um backend HTTPS configurado. Filmes, séries, anime, EPG e geração de legendas ainda são pontos de integração, não serviços completos.
