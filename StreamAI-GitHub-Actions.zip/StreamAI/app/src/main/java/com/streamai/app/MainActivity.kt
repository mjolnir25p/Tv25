package com.streamai.app

import android.content.Context
import android.os.Bundle
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.net.URL
import java.net.HttpURLConnection
import org.json.JSONObject

private const val PLAYLIST = "https://iptv-org.github.io/iptv/index.m3u"
private const val EPG_HINT = "https://iptv-org.github.io/epg/"

data class Channel(val name:String, val url:String, val group:String="TV", val id:String="", val logo:String="", val country:String="")
enum class Tab(val label:String){ HOME("Início"), TV("TV"), MOVIES("Filmes"), SERIES("Séries"), ANIME("Anime"), AI("AI") }

class MainActivity: ComponentActivity(){ override fun onCreate(savedInstanceState: Bundle?){ super.onCreate(savedInstanceState); setContent { StreamApp() } } }

class FavoritesStore(context: Context){
 private val prefs=context.getSharedPreferences("streamai",Context.MODE_PRIVATE)
 fun all():Set<String> = prefs.getStringSet("favorites", emptySet()) ?: emptySet()
 fun toggle(url:String){ val next=all().toMutableSet(); if(!next.add(url)) next.remove(url); prefs.edit().putStringSet("favorites",next).apply() }
}

@Composable fun StreamApp(){
 var tab by remember { mutableStateOf(Tab.HOME) }; var selected by remember { mutableStateOf<Channel?>(null) }
 MaterialTheme(colorScheme=darkColorScheme()) { Scaffold(bottomBar={ NavigationBar { Tab.entries.forEach { t -> NavigationBarItem(selected=tab==t,onClick={tab=t},icon={Icon(when(t){Tab.HOME->Icons.Default.Home;Tab.TV->Icons.Default.LiveTv;Tab.MOVIES->Icons.Default.Movie;Tab.SERIES->Icons.Default.Tv;Tab.ANIME->Icons.Default.Animation;Tab.AI->Icons.Default.AutoAwesome},null)},label={Text(t.label)}) } } }) { p ->
  Box(Modifier.padding(p).fillMaxSize()){ if(selected!=null) PlayerScreen(selected!!){selected=null} else when(tab){ Tab.HOME->Home{tab=Tab.TV}; Tab.TV->TvScreen{selected=it}; Tab.MOVIES->CatalogPlaceholder("Filmes"); Tab.SERIES->CatalogPlaceholder("Séries"); Tab.ANIME->CatalogPlaceholder("Anime"); Tab.AI->AiScreen() } }
 } }
}

@Composable fun Home(openTv:()->Unit){ Column(Modifier.padding(24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){ Text("StreamAI",style=MaterialTheme.typography.displaySmall); Text("TV ao vivo, catálogo autorizado e recursos AI",style=MaterialTheme.typography.titleMedium); Button(onClick=openTv,modifier=Modifier.focusable()){Icon(Icons.Default.PlayArrow,null);Spacer(Modifier.width(8.dp));Text("Ver TV ao vivo")}; HorizontalDivider(); Text("Descobrir",style=MaterialTheme.typography.headlineSmall); Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(12.dp)){ listOf("TV ao vivo","Favoritos","Notícias","Desporto","Música","Cultura").forEach{ AssistChip(onClick=openTv,label={Text(it)},modifier=Modifier.focusable()) } }; Text("Os canais são obtidos da playlist pública IPTV-org em tempo de execução. Filmes, séries e anime devem ser ligados apenas a fontes para as quais tenhas autorização.") } }

@Composable fun TvScreen(open:(Channel)->Unit){
 val context=LocalContext.current; val store=remember{FavoritesStore(context)}
 var channels by remember{mutableStateOf<List<Channel>>(emptyList())}; var q by remember{mutableStateOf("")}; var error by remember{mutableStateOf<String?>(null)}; var group by remember{mutableStateOf("Todos")}; var favorites by remember{mutableStateOf(store.all())}; var onlyFav by remember{mutableStateOf(false)}
 LaunchedEffect(Unit){ runCatching{withContext(Dispatchers.IO){parseM3u(URL(PLAYLIST).readText())}}.onSuccess{channels=it}.onFailure{error=it.message} }
 val groups=remember(channels){ listOf("Todos")+channels.map{it.group}.filter{it.isNotBlank()}.distinct().sorted().take(60) }
 val filtered=channels.asSequence().filter{(group=="Todos"||it.group==group)&&(!onlyFav||it.url in favorites)&&(q.isBlank()||it.name.contains(q,true)||it.group.contains(q,true)||it.country.contains(q,true))}.take(1200).toList()
 Column(Modifier.padding(16.dp)){ Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Text("TV ao vivo",style=MaterialTheme.typography.headlineMedium); if(channels.isNotEmpty()) Badge{Text(channels.size.toString())}}; OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),label={Text("Pesquisar canal, categoria ou país")},leadingIcon={Icon(Icons.Default.Search,null)}); Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){ FilterChip(selected=onlyFav,onClick={onlyFav=!onlyFav},label={Text("Favoritos")},leadingIcon={Icon(Icons.Default.Favorite,null)}); groups.forEach{g->FilterChip(selected=group==g,onClick={group=g},label={Text(g)},modifier=Modifier.focusable())} }; Spacer(Modifier.height(8.dp)); when{ error!=null->Text("Erro ao carregar: $error"); channels.isEmpty()->CircularProgressIndicator(); else->LazyColumn{items(filtered,key={it.url}){c->ListItem(headlineContent={Text(c.name)},supportingContent={Text(listOf(c.group,c.country).filter{it.isNotBlank()}.joinToString(" • "))},leadingContent={Icon(Icons.Default.LiveTv,null)},trailingContent={IconButton(onClick={store.toggle(c.url);favorites=store.all()}){Icon(if(c.url in favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder,"Favorito")}},modifier=Modifier.clickable{open(c)}.focusable());HorizontalDivider()}} } }
}

fun attr(line:String,key:String)=Regex("$key=\"([^\"]*)\"").find(line)?.groupValues?.get(1).orEmpty()
fun parseM3u(text:String):List<Channel>{ val out=mutableListOf<Channel>(); var pending:Channel?=null; text.lineSequence().forEach{raw->val line=raw.trim(); if(line.startsWith("#EXTINF")){ pending=Channel(name=line.substringAfterLast(',').trim().ifBlank{"Canal"},url="",group=attr(line,"group-title").ifBlank{"TV"},id=attr(line,"tvg-id"),logo=attr(line,"tvg-logo"),country=attr(line,"tvg-country")) } else if(line.startsWith("http")){ val p=pending?:Channel("Canal",line); out+=p.copy(url=line); pending=null } }; return out.distinctBy{it.url} }

@Composable fun PlayerScreen(c:Channel,back:()->Unit){ val context=LocalContext.current; val player=remember(c.url){ExoPlayer.Builder(context).build().apply{setMediaItem(MediaItem.fromUri(c.url));prepare();playWhenReady=true}}; DisposableEffect(player){onDispose{player.release()}}; Column{Row(Modifier.padding(8.dp)){IconButton(onClick=back){Icon(Icons.Default.ArrowBack,null)};Column{Text(c.name,style=MaterialTheme.typography.titleLarge);Text(c.group,style=MaterialTheme.typography.bodySmall)}};AndroidView(factory={PlayerView(it).apply{this.player=player;useController=true;layoutParams=ViewGroup.LayoutParams(-1,-1)}},modifier=Modifier.fillMaxSize())} }

@Composable fun CatalogPlaceholder(title:String){ Column(Modifier.padding(24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text(title,style=MaterialTheme.typography.headlineMedium);Text("Liga aqui um catálogo próprio/licenciado. A UI já está separada da TV ao vivo para permitir VOD, temporadas, episódios, histórico e continuar a ver.");OutlinedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Icon(Icons.Default.VideoLibrary,null);Text("Fonte autorizada não configurada",style=MaterialTheme.typography.titleMedium);Text("Adiciona o teu backend/API de catálogo sem incorporar fontes não licenciadas no APK.")}}} }

suspend fun postJson(endpoint:String,path:String,payload:JSONObject):String = withContext(Dispatchers.IO){
 val base=endpoint.trimEnd('/'); val conn=(URL(base+path).openConnection() as HttpURLConnection).apply{requestMethod="POST";connectTimeout=15000;readTimeout=60000;doOutput=true;setRequestProperty("Content-Type","application/json");setRequestProperty("Accept","application/json")}
 conn.outputStream.bufferedWriter().use{it.write(payload.toString())}; val code=conn.responseCode; val body=(if(code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use{it.readText()}.orEmpty(); conn.disconnect(); if(code !in 200..299) error("HTTP $code: $body"); body
}

@Composable fun AiScreen(){ var prompt by remember{mutableStateOf("")}; var endpoint by remember{mutableStateOf("")}; var answer by remember{mutableStateOf("")}; var busy by remember{mutableStateOf(false)}; val scope=rememberCoroutineScope(); Column(Modifier.padding(24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Assistente AI",style=MaterialTheme.typography.headlineMedium);Text("O APK envia pedidos para o teu backend. Mantém chaves e credenciais no servidor.");OutlinedTextField(endpoint,{endpoint=it},Modifier.fillMaxWidth(),label={Text("URL HTTPS do teu backend AI")});OutlinedTextField(prompt,{prompt=it},Modifier.fillMaxWidth(),label={Text("Ex.: mostra canais portugueses de notícias")});Button(onClick={scope.launch{busy=true;answer=""; runCatching{postJson(endpoint,"/chat",JSONObject().put("message",prompt))}.onSuccess{raw->answer=runCatching{JSONObject(raw).optString("answer",raw)}.getOrDefault(raw)}.onFailure{answer="Erro: ${it.message}"};busy=false}},enabled=endpoint.startsWith("https://")&&prompt.isNotBlank()&&!busy){Icon(Icons.Default.AutoAwesome,null);Spacer(Modifier.width(8.dp));Text(if(busy) "A enviar…" else "Enviar")}; if(answer.isNotBlank()) OutlinedCard(Modifier.fillMaxWidth()){Text(answer,Modifier.padding(16.dp))};HorizontalDivider();Text("Legendas AI",style=MaterialTheme.typography.titleLarge);Text("Contrato sugerido: POST /subtitles com referência a mídia autorizada → transcrição temporizada → tradução opcional → WebVTT/SRT. O resultado pode ser anexado ao Media3 como faixa de legendas.");Text("EPG",style=MaterialTheme.typography.titleLarge);Text("O projeto deixa o tvg-id disponível para casar canais com XMLTV. Ponto de integração: $EPG_HINT") } }
