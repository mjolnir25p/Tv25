# StreamAI AI backend contract

Never place provider API keys in the Android APK. The app accepts an HTTPS backend base URL.

## POST /chat
Request: `{"message":"mostra canais portugueses de notícias"}`
Response: `{"answer":"..."}`

The backend should restrict the assistant to your authorized catalogue and public channel metadata.

## POST /subtitles
Suggested request: `{"mediaId":"authorized-media-id","language":"pt"}`
Suggested response: `{"format":"vtt","url":"https://.../captions.vtt"}`

The server should only transcribe media you are authorized to process. Return a short-lived HTTPS URL or the caption text. Media3 can attach WebVTT as an external subtitle configuration.
