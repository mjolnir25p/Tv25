# StreamAI

App Android nativa: TV pública IPTV-org, pesquisa, favoritos locais e Media3. Assistente com cliente HTTPS configurável. Catálogos e legendas AI precisam de backend. Consulte BUILD.md e AI_BACKEND.md.
