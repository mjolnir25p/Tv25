# Adicionar ao Tv25

Extrai este ZIP e envia a pasta StreamAI e o ficheiro .github/workflows/streamai-apk.yml para a raiz do repositório mjolnir25p/Tv25. Não envies o ZIP fechado. Se o gestor de ficheiros ocultar .github, cria o ficheiro no GitHub com Add file > Create new file e usa esse caminho.

O novo workflow chama-se Build StreamAI APK e arranca ao guardar em main. Abre Actions, aguarda a conclusão e descarrega StreamAI-debug-APK em Artifacts. Extrai e instala app-debug.apk.

Tags streamai-v* geram uma release com o APK de teste. Não é necessária chave AI para compilar; o assistente precisa de um backend HTTPS em execução.

O pacote foi revisto, mas ainda não foi compilado. A ligação GitHub recusou a escrita (403), por isso não foi publicado no repositório.
