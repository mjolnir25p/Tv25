# TV25 Android

Projeto Android de teste para executar o TV25 numa WebView.

## Gerar o APK sem Android Studio

1. Cria um repositório novo no GitHub.
2. Envia **o conteúdo desta pasta** para a raiz do repositório (incluindo a pasta `.github`).
3. Abre o separador **Actions** do repositório.
4. Escolhe **Build TV25 APK**.
5. Carrega em **Run workflow** e confirma.
6. Quando terminar, abre a execução concluída e, em **Artifacts**, descarrega **TV25-APK**.
7. Extrai o ZIP descarregado. Dentro estará `TV25.apk`.
8. Copia `TV25.apk` para o IIIF150 B2 Pro e instala-o.

O APK gerado é uma versão **debug**, indicada para testes pessoais. O Android poderá pedir autorização para instalar aplicações provenientes do browser/gestor de ficheiros.

## Código da aplicação

- HTML TV25: `app/src/main/assets/index.html`
- Android/WebView: `app/src/main/java/pt/tv25/app/MainActivity.kt`
- Manifesto: `app/src/main/AndroidManifest.xml`
- Workflow: `.github/workflows/build-apk.yml`
