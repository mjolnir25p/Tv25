plugins { id("com.android.application") }

android {
    namespace = "pt.tv25.app"
    compileSdk = 35
    defaultConfig { applicationId = "pt.tv25.app"; minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "2.0-test" }
}
